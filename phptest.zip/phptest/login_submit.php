<?php
//including the database connection file
include_once ("database.php");
 
$database = new Database();
 
if(isset($_POST['Submit'])) {    
    $username = $_POST['username'];
    $password = md5($_POST['password']);
   
	if($username !="" && $password !=""){
		$res = $database->login_submit($username, $password);
		if(count($res)>0){
			$_SESSION['username']=$username;
			header("location:product.php");
		}
		else{
			$_SESSION['message']="<span style='color:red;'>Username or Password is invalid</span>"; 
			header("location:login.php");
		}
        
    }
    else{
		$_SESSION['message']="<span style='color:red;'>Username and Password should not be blank</span>"; 
        header("location:login.php");
    }      
       

} 
?>