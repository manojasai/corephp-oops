
<html>
<head>
    <title>Register</title>
</head>
 
<body>
    <a href="index.php">Register</a>
    <br/><br/>
 
    <form action="register_submit.php" method="post" name="form1">
        <table width="25%" border="0">
            <tr> 
                <td>UserName</td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr> 
                <td>Password</td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr> 
                <td>Confirm Password</td>
                <td><input type="password" name="cpassword"></td>
            </tr>
            <tr> 
                <td></td>
                <td><input type="submit" name="Submit" value="Register"></td>
            </tr>
        </table>
    </form>
	<?php
			if(isset($_SESSION['message'])){
				echo $_SESSION['message'];
			}
			unset( $_SESSION['message'] );
		?>
</body>
</html>