<?php
//including the database connection file
include_once ("database.php");
 
$database = new Database();
 
if(isset($_POST['Submit'])) {    
    $username = $_POST['username'];
    $password = md5($_POST['password']);
   
	if($username !="" && $password !=""){
		$res = $database->register_submit($username, $password);
		
        header("location:login.php");
    }
    else{
		$_SESSION['message']="<span style='color:red;'>Username and Password should not be blank</span>"; 
        header("location:register.php");
    }      
       

} 
?>