<?php
error_reporting(E_ALL);
class Database 
{    
    private  $connection;
    
    public function __construct()
    {
            
		$this->connection = mysqli_connect('localhost', 'root', '', 'phptest');
		
		if (mysqli_connect_error()) {
			echo 'Cannot connect to database server';
			exit;
		} 
		else{
			echo "Connected";
		}
        
        $this->connection;
    }
	
	public function register_submit($username, $password)
	{
		$sql = "INSERT INTO `user` (username, password) VALUES ('$username', '$password')";
		$res = mysqli_query($this->connection, $sql);
		return $res;
	} 
	
	public function login_submit($username, $password)
	{
		$sql = "SELECT * from user where username='$username' AND password='$password'";
		$res = mysqli_query($this->connection, $sql);
		$row=$res->fetch_assoc();
		return $row;
	} 
}

//$database = new Database();
//$database->connect_db();
?>